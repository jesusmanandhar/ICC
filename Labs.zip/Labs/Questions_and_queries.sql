1. Create a Sales table using sale_id, product_id, quantity_sold , sale_date , total_price with FOREIGN KEY (product_id) REFERENCES Products(product_id), and insert 10 data.

	CREATE TABLE Sales (
	  sale_id       INT            AUTO_INCREMENT PRIMARY KEY,
	  product_id    INT            NOT NULL,
	  quantity_sold INT            NOT NULL,
	  sale_date     DATE           NOT NULL,
	  total_price   DECIMAL(12,2)  NOT NULL,
	  FOREIGN KEY (product_id) REFERENCES Products(product_id)
	);

	INSERT INTO Sales (product_id, quantity_sold, sale_date, total_price) VALUES
	  (1,  10, '2025-01-01',  150.00),
	  (2,   5, '2025-01-02',  127.50),
	  (3,   1, '2025-01-03',   99.99),
	  (4,  20, '2025-01-03', 2980.00),
	  (5,  15, '2025-01-04',  686.25),
	  (6,  10, '2025-01-05',  552.50),
	  (7, 100, '2025-01-06', 1210.00),
	  (8,  50, '2025-01-07', 1110.00),
	  (9,   2, '2025-01-08',  150.00),
	  (10,  1, '2025-01-09',  120.00);

2. Create a Product table using product_id, product_name , category, unit_price and insert 10 data.

	CREATE TABLE Products (
	  product_id     INT            AUTO_INCREMENT PRIMARY KEY,
	  product_name   VARCHAR(100)   NOT NULL,
	  category       VARCHAR(50)    NOT NULL,
	  unit_price     DECIMAL(10,2)  NOT NULL,
	  stock_quantity INT            NOT NULL  DEFAULT 0
	);

	INSERT INTO Products (product_name, category, unit_price, stock_quantity) VALUES
	  ('Widget A', 'Widgets',  15.00, 100),
	  ('Widget B', 'Widgets',  25.50,  80),
	  ('Gadget X', 'Gadgets',  99.99,  50),
	  ('Gadget Y', 'Gadgets', 149.00,  60),
	  ('Tool Alpha', 'Tools',  45.75, 120),
	  ('Tool Beta',  'Tools',  55.25, 110),
	  ('Part 123',  'Parts',  12.10, 200),
	  ('Part 456',  'Parts',  22.20, 150),
	  ('Item One',  'Misc',   75.00,  70),
	  ('Item Two',  'Misc',  120.00,  40);
	  
  
3. Retrieve all columns from the Sales table.
  
	  SELECT * FROM Sales;
  
  
4. Retrieve the product_name and unit_price from the Products table.
  
	  SELECT product_name, unit_price FROM Products;
  
  
5. Retrieve the sale_id and sale_date from the Sales table.
  
	  SELECT sale_id, sale_date FROM Sales;
  
  
 6. Filter the Sales table to show only sales with a total_price greater than $1570.
  
	  SELECT * FROM Sales WHERE total_price > 1570;
  
  
7. Retrieve the sale_id and total_price from the Sales table for sales made on January 3, 2025.
  
	  SELECT sale_id, total_price 
	  FROM Sales 
	 WHERE sale_date = '2025-01-03';
 
 
8. Calculate the total revenue generated from all sales in the Sales table.
 
	 SELECT SUM(total_price) AS total_revenue FROM Sales;
 
 
9. Calculate the average unit_price of products in the Products table.
 
	 SELECT AVG(unit_price) AS avg_unit_price FROM Products;
 
 
10. Count Sales Per Day from the Sales table.
 
	 SELECT sale_date, COUNT(*) AS sales_count 
	  FROM Sales 
	 GROUP BY sale_date 
	 ORDER BY sale_date;
 
 
11. Retrieve the total_price of all sales, rounding the values to two decimal places.
 
	 SELECT ROUND(total_price,2) AS total_price_rounded FROM Sales;
 
 
12. Retrieve the sale_id and sale_date from the Sales table, formatting the sale_date as 'YYYY-MM-DD'.
 
	 SELECT sale_id, DATE_FORMAT(sale_date,'%Y-%m-%d') AS sale_date_fmt FROM Sales;
 
 
13. Rank products based on total sales revenue.
 
	 SELECT 
	  p.product_id,
	  p.product_name,
	  SUM(s.total_price) AS revenue,
	  RANK() OVER (ORDER BY SUM(s.total_price) DESC) AS revenue_rank
	FROM Products p
	JOIN Sales    s USING (product_id)
	GROUP BY p.product_id, p.product_name
	ORDER BY revenue DESC;

 
14. Categorize sales as "High", "Medium", or "Low" based on total price (e.g., > $2000 is High, $1100-$1999 is Medium, < $1099 is Low)

	SELECT 
	  sale_id,
	  total_price,
	  CASE
	    WHEN total_price > 2000                THEN 'High'
	    WHEN total_price BETWEEN 1100 AND 1999 THEN 'Medium'
	    ELSE 'Low'
	  END AS price_category
	FROM Sales;


15. Retrieve the product details (name, category, unit price) for products that have a quantity sold greater than the average quantity sold across all products.

	SELECT DISTINCT 
	  p.product_id,
	  p.product_name,
	  p.category,
	  p.unit_price
	FROM Products p
	JOIN Sales    s USING (product_id)
	WHERE s.quantity_sold > (
	  SELECT AVG(quantity_sold) FROM Sales
	);


16. Add a foreign key constraint to the Sales table that references the product_id column in the Products table.

already done in step 1-2


17. Implement a transaction that deducts the quantity sold from the Products table when a sale is made in the Sales table, ensuring that both operations are either committed or rolled back together.

	DELIMITER $$
	CREATE PROCEDURE Make_Sale(
	  IN in_product_id    INT,
	  IN in_quantity_sold INT
	)
	BEGIN
	  DECLARE price_per_unit DECIMAL(10,2);
	  
	  START TRANSACTION;
	    SELECT unit_price INTO price_per_unit 
	      FROM Products 
	     WHERE product_id = in_product_id 
	       AND stock_quantity >= in_quantity_sold
	     FOR UPDATE;
	    
	    IF price_per_unit IS NULL THEN
	      ROLLBACK;
	      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient stock';
	    ELSE
	      INSERT INTO Sales (product_id, quantity_sold, sale_date, total_price)
	      VALUES (in_product_id, in_quantity_sold, CURDATE(), in_quantity_sold * price_per_unit);
	      
	      UPDATE Products
		 SET stock_quantity = stock_quantity - in_quantity_sold
	       WHERE product_id = in_product_id;
	      
	      COMMIT;
	    END IF;
	END$$
	DELIMITER ;

	SHOW CREATE PROCEDURE Make_Sale\G

	SELECT product_id, stock_quantity FROM Products WHERE product_id=2\G

	CALL Make_Sale(2,3)\G

	SELECT stock_quantity FROM Products WHERE product_id=2\G
	SELECT * FROM Sales WHERE product_id=2 AND sale_date=CURDATE()\G


18. Write a query to find all sales where the total price is greater than the average total price of all sales.

	SELECT * 
	  FROM Sales 
	 WHERE total_price > (SELECT AVG(total_price) FROM Sales);
 
 
19. Develop a stored procedure named Update_Unit_Price that updates the unit price of a product in the Products table based on the provided product_id.

	DELIMITER $$
	CREATE PROCEDURE Update_Unit_Price (
	  IN pid       INT,
	  IN new_price DECIMAL(10,2)
	)
	BEGIN
	  UPDATE Products
	     SET unit_price = new_price
	   WHERE product_id = pid;
	END$$
	DELIMITER ;

	SHOW CREATE PROCEDURE Update_Unit_Price\G

	SELECT product_id, unit_price
	  FROM Products
	 WHERE product_id = 4\G

	CALL Update_Unit_Price(4, 159.99)\G

	SELECT product_id, unit_price
	  FROM Products
	 WHERE product_id = 4\G


20. Implement a transaction that inserts a new product into the Products table and then adds a corresponding sale record into the Sales table, ensuring that both operations are either fully completed or fully rolled back.

	DELIMITER $$
	CREATE PROCEDURE Add_Product_And_Sale(
	  IN pname    VARCHAR(100),
	  IN pcat     VARCHAR(50),
	  IN pprice   DECIMAL(10,2),
	  IN pstock   INT,
	  IN qty_sold INT
	)
	BEGIN
	  DECLARE new_pid INT;
	  START TRANSACTION;
	    INSERT INTO Products (product_name, category, unit_price, stock_quantity)
	    VALUES (pname, pcat, pprice, pstock);
	    SET new_pid = LAST_INSERT_ID();
	    INSERT INTO Sales (product_id, quantity_sold, sale_date, total_price)
	    VALUES (new_pid, qty_sold, CURDATE(), qty_sold * pprice);
	    UPDATE Products
	       SET stock_quantity = stock_quantity - qty_sold
	     WHERE product_id = new_pid
	       AND stock_quantity >= qty_sold;
	    IF ROW_COUNT() = 0 THEN
	      ROLLBACK;
	      SIGNAL SQLSTATE '45000' 
		SET MESSAGE_TEXT = 'Insufficient stock for new product sale';
	    ELSE
	      COMMIT;
	    END IF;
	END$$
	DELIMITER ;


	SELECT MAX(product_id) AS max_pid, COUNT(*) AS total_products FROM Products;
	SELECT MAX(sale_id)    AS max_sid,  COUNT(*) AS total_sales    FROM Sales;

	CALL Add_Product_And_Sale('New Gizmo','Gadgets',199.99,50,2);

	SELECT MAX(product_id) AS max_pid, COUNT(*) AS total_products FROM Products;
	SELECT MAX(sale_id)    AS max_sid,  COUNT(*) AS total_sales    FROM Sales;


